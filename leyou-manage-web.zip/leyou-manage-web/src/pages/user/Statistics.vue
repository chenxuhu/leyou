<template>
  <div>statistics</div>
</template>

<script>
    export default {
        name: "statistics"
    }
</script>

<style scoped>

</style>
